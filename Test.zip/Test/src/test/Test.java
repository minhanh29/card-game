
package test;
import java.util.*;
import java.io.IOException;

/**
 *
 * @author minhanh
 */
public class Test {

    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        String answer, decision;
        boolean answerBool = false;
        
        System.out.print("Enter the numer of cards: ");
        int number = scan.nextInt();
        CardSet deck = new CardSet(number);
        
        do
        {
            deck.shuffle();
            System.out.println("\n Shuffled Deck: ");
            deck.spread();
            
            System.out.println("Start game? (yes/no)");
            decision = scan.next();
        } while (!decision.equals("yes"));
        
        deck.eliminate();
        deck.spread();
        
        System.out.println("Which card was eliminated? ");
        for (int i = 0; i < 3; i++)
        {
            System.out.print("Your answer: ");
            answer = scan.next();
            if (answer.equals(deck.getChosenCard()))
            {
                answerBool = true;
                break;
            }
        } 
        
        if (answerBool == true)
            System.out.println("Congratulaions! You are awesome!");
        else
        {
            System.out.println("So sorry! The answer is " + deck.getChosenCard() + " !");
            System.out.println("Let's try again!");
        }
        
        deck.recover();
    }
    
    public static void clearScreen()
    {
        //???
    }
}
