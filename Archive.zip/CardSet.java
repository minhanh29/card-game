/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;
import java.util.*;
/**
 *
 * @author minhanh
 */
public class CardSet {
    private Card cardDeck = new Card();
    private int numberOfCards;
    private String chosenCard;
    private int chosenCardIndex;
    
    public CardSet(int number)
    {
        int remove = 52 - number;
        for (int i = 0; i < remove; i ++)
        {
            cardDeck.remove(51-i);
        }
        
        numberOfCards = number;
    }
    
    public void shuffle()
    {
        ArrayList<String> newDeck = new ArrayList<>();
        Random generator = new Random();
        
        for (int i = 0; i < numberOfCards; i++)
        {
            int index;
            String cardName;
            
            do{
                index = generator.nextInt(numberOfCards);
                cardName = cardDeck.get(index);
            } while (newDeck.contains(cardName));
            
            newDeck.add(i, cardName);
        }
        
        for (int i = 0; i < numberOfCards; i++)
        {
            cardDeck.replace(i, newDeck.get(i));
        }
    }
    
    public String get(int i)
    {
        return cardDeck.get(i);
    }
    
    public void spread()
    {
        int line1 = (int)Math.ceil(numberOfCards/4.0);
        int count = 0;
        for (int j = 0; j < 4; j++)
        {
            int line2 = line1 + count;
            for (int i = count; i < line2; i++)
            {
            count = i;
            if (i < numberOfCards)
                System.out.print(cardDeck.get(i) + "\t");
            }
            System.out.println();
            count++;
        }
    }
    
    public void eliminate()
    {
        Random ran = new Random();
        chosenCardIndex = ran.nextInt(numberOfCards);
        
        chosenCard = cardDeck.get(chosenCardIndex);
        cardDeck.replace(chosenCardIndex, "  ");
    }
    
    public String getChosenCard()
    {
        return chosenCard;
    }
    
    public void recover()
    {
        cardDeck.replace(chosenCardIndex, chosenCard);
    }
}
