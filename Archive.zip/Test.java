/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;
import java.util.*;
import java.io.IOException;

/**
 *
 * @author minhanh
 */
public class Test {

    public static void main(String[] args)
    {
        CardSet deck = new CardSet(4);
        Scanner scan = new Scanner(System.in);
        String answer, decision;
        boolean answerBool = false;
        
        System.out.println("New Deck:");
        deck.spread();
        
        do
        {
            deck.shuffle();
            System.out.println("\n Shuffled Deck: ");
            deck.spread();
            
            System.out.println("Start game? (yes/no)");
            decision = scan.nextLine();
        } while (!decision.equals("yes"));
        
        System.out.print("\033[H\033[2J");
        deck.eliminate();
        deck.spread();
        
        System.out.println("Which card was eliminated? ");
        for (int i = 0; i < 3; i++)
        {
            System.out.print("Your answer: ");
            answer = scan.nextLine();
            if (answer.equals(deck.getChosenCard()))
            {
                answerBool = true;
                break;
            }
        } 
        
        if (answerBool == true)
            System.out.println("Congratulaions! You are awesome!");
        else
        {
            System.out.println("So sorry! The answer is " + deck.getChosenCard() + " !");
            System.out.println("Let's try again!");
        }
        
        deck.recover();
    }
    
    public static void clearScreen()
    {
        Runtime r = Runtime.getRuntime();
        
        try
        {
            r.exec("mkdir NEW_DIR");
        } catch (IOException E)
        {
            E.printStackTrace();
        }
    }
}
