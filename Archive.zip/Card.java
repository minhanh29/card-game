/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;
import java.util.*;
/**
 *
 * @author minhanh
 */
public class Card {
    ArrayList<String> deck = new ArrayList<>();
    
    /**
     *
     */
    public Card()
    {
        for (int i = 0; i < 13; i++)
        {
            deck.add(i,("" + (i + 1) + "S"));
        }
        
        for (int i = 13; i < 26; i++)
        {
            deck.add(i,("" + (i + 1) + "H"));
        }
        
        for (int i = 26; i < 39; i++)
        {
            deck.add(i,("" + (i + 1) + "C"));
        }
        
        for (int i = 39; i < 52; i++)
        {
            deck.add(i,("" + (i + 1) + "D"));
        }
        
    }
    
    public void add(int i, String str)
    {
        deck.add(i, str);
    }
    
    public void remove(int i)
    {
        deck.remove(i);
    }
    
    public void replace(int i, String str)
    {
        deck.remove(i);
        deck.add(i, str);
    }
    
    public String get(int i)
    {
        return deck.get(i);
    }
}
